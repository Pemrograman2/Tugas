# -*- coding: utf-8 -*-
"""
Created on Thu Nov 21 11:09:27 2019

@author: Lenovo
"""

import lib3
class Kelas3lib:
    def __init__(self,npm):
        self.npm = npm
    def soal1(self):
        return lib3.soal1()
    def soal2(self):
        return lib3.soal2(self.npm)
    def soal33(self):
        return lib3.soal3(self.npm)
    def soal4(self):
        return lib3.soal4(self.npm)
    def soal5(self):
        return lib3.soal5(self.npm)
    def soal6(self):
        return lib3.soal6(self.npm)
    def soal7(self):
        return lib3.soal7(self.npm)
    def soal8(self):
        return lib3.soal8(self.npm)
    def soal9(self):
        return lib3.soal9(self.npm)
    def soal10(self):
        return lib3.soal10(self.npm)

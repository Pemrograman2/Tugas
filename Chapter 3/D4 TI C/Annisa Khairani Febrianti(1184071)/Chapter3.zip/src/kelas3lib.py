# -*- coding: utf-8 -*-
"""
Created on Tue Nov 12 20:33:02 2019

@author: NISA
"""

import lib3
class Kelas3lib:
    def __init__(self,npm):
        self.npm = npm
    def npm1(self):
        return lib3.npm1()
    def npm2(self):
        return lib3.npm2(self.npm)
    def npm3(self):
        return lib3.npm3(self.npm)
    def npm4(self):
        return lib3.npm4(self.npm)
    def npm5(self):
        return lib3.npm5(self.npm)
    def npm6(self):
        return lib3.npm6(self.npm)
    def npm7(self):
        return lib3.npm7(self.npm)
    def npm8(self):
        return lib3.npm8(self.npm)
    def npm9(self):
        return lib3.npm9(self.npm)
    def npm10(self):
        return lib3.npm10(self.npm)
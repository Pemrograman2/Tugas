# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 17:48:17 2019

@author: Lenovo
"""

npm=int(input("Masukan Npm kamu :"))
Z = npm%100
for i in range(Z):
    print("Halo ", npm," Apakabar")
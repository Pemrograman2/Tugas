# -*- coding: utf-8 -*-
"""
Created on Wed Oct 23 21:21:33 2019

@author: Lenovo
"""

NPM = input("npm kamu: ")

print("Halo, ",NPM[4]," Apa kabar?")

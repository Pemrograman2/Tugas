p="3"
u=3

try:
    p+u
except:
    print(Eror, hanya bisa digabungkan string dengan string")
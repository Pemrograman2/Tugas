# biodata mahasiswa
nama = "Alifia Zahra"
alamat = 'Sukabumi'
umur = 18
tinggi = 156.5

print("Nama :", nama)
print("Alamat :", alamat)
print ("Umur :", umur)
print ("Tinggi :", tinggi)

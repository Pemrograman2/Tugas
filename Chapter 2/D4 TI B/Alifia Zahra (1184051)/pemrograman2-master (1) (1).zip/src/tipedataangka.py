berat = 40.5 #float
harga = 1000

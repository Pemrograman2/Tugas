nama = input("Siapa nama kamu?: ")
umut = input("Umur kamu berapa?: ")

print("Hello", nama, "Umur kamu adalah", 18) #output


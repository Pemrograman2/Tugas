# biodata mahasiswa
nama = "Annisa Khairani Febrianti"
alamat = 'Jambi'
umur = 19
tinggi = 160

print("Nama :", nama)
print("Alamat :", alamat)
print("Umur :", umur)
print("Tinggi :", tinggi)

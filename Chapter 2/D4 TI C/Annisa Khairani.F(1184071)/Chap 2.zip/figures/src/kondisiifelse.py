umur = 15
if umur >= 16:
    print("Anda sudah cukup umur dan dapat membuat SIM")
else:
    print("Anda belum cukup umur dan belum bisa membuat SIM")


ulang = 5

for i in  (ulang):
    print("Perulangan ke-"+str(i))
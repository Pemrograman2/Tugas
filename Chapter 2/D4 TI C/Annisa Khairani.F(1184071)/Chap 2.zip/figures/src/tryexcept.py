try:
    print("Hello")
except:
    print("Ada yang error")
else:
    print("Tidak ada yang error")
nama = input("Siapa nama anda?: ")
umur = input("Umur kamu berapa?: ")

print("Hello",nama,"Umur kamu adalah", 19)
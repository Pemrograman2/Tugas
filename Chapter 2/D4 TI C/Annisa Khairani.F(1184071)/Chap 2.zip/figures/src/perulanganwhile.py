jawab = 'ya'
hitung = 0

while(jawab == 'ya'):
    hitung += 1
    jawab = input ("Ulang lagi? ")
    
print("Total perulangan: " + str(hitung))
r="10"
s=10

try:
    r+s
except:
    print("Akan error dikarenakan hanya bisa digabungkan dengan string dengan string )
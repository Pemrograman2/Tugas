a = int(input('Masukkan nilai a: '))
b = int(input('Masukkan nilai b: '))

# operator penjumlahan
c = a + b
print ("Hasil %d + %d = %d" % (a,b,c))

# operator pengurangan
c = a - b
print ("Hasil %d - %d = %d" %(a,b,c))

# operator perkalian
c = a * b
print ("Hasil %d * %d = %d" %(a,b,c))

# operator pembagian
c = a / b
print ("Hasil %d /30 %d = %d" %(a,b,c))
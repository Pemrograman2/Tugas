umur = 19
if umur >= 17:
    print("Anda sudah cukup umur dan dapat membuat SIM" )


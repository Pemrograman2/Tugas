a= input('Masukkan nilai a: ')
b= input('Masukkan nilai b: ')
 
# operator penjumlahan
c = a + b
try:
    print("Hasil %d + %d = %d" % (a,b,c))
except:
    print("Maaf tidak sesuai")
berat = 50.5 #float
harga = 2000 #int


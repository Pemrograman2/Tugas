NPM=int(input("Masukkan NPM :")) # Membuat variabel dan inputan user
Tld=NPM%100 #
for i in range(Tld): # pengulangan i dalam batas (range) untuk int
    print("Hallo ",NPM," How are you ?") #output1

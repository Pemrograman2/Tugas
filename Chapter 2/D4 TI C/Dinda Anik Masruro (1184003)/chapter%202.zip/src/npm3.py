NPM=input("Masukan Npm anda: ")

X =int(NPM[4])
Y =int(NPM[5])
Z =int(NPM[6])

hitung1 = X + Y + Z
hitung2 = X + Y + Z

while hitung1 > 0:
        print("Halo, ", NPM[4:7], "Apa kabar ?")
        hitung1 = hitung1 -1
print("...",str(hitung2),"kali(",str(X),"+",str(Y),"+"+str(Z),")...")   
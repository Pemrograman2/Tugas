berat = 54 #float
harga = 5000 #int
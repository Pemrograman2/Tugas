r="5"
s=5

try:
    r+s
except:
    print("Akan error dikarenakan hanya bisa digabungkan string dengan string atau int dengan int")
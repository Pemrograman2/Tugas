nama = input("Siapa nama kamu?: ")
umur = input("Umur kamu berapa?: ")

print("Hello", nama, "Umur kamu adalah", 20)
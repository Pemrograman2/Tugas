# biodata mahasiswa
nama = "Dinda Anik Masruro"
alamat = 'Lumajang'
umur = 20
tinggi = 156

print("Nama :", nama)
print("Alamat :", alamat)
print("Umur :", umur)
print("Tinggi :", tinggi)
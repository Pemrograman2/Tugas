NPM = input("Npm anda: ")

print("Halo, ",NPM[4]," Apa kabar?")

umur = 19
if umur > 17:
    print("Anda sudah cukup umur untuk membuat KTP")